import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class EventService {

  url:String ="http://localhost:9091/event";

  constructor(private http:HttpClient) { }

  public showAllEvents():Observable<any>{
    return this.http.get<any>(this.url +"/getallevents");
  }
}
