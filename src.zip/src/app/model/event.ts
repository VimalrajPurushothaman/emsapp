export interface Event {
    eventId: string;
    name: string;
    category: string;
    location: string;
    regDate: Date;
    url: string;
    description: string;
    maxCount: number;
    startDateTime: Date;
    endDateTime: Date;
    price: number;
    organizerId: string;
  }
  