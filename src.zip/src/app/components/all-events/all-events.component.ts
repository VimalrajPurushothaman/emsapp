import { Component } from '@angular/core';
import { EventService } from 'src/app/services/event.service';
import { Event } from 'src/app/model/event';
@Component({
  selector: 'app-all-events',
  templateUrl: './all-events.component.html',
  styleUrls: ['./all-events.component.css']
})
export class AllEventsComponent {

  events :Event[]=[];

  constructor(private ser:EventService){

  }

  
  ngOnInit(): void {
    this.getAllEvents();
  }
  

  

  public getAllEvents():void{
    this.ser.showAllEvents().subscribe((p) => this.events=p);
  }

}
